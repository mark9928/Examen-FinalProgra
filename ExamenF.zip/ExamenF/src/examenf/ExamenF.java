
package examenf;


public class ExamenF {


    public static void main(String[] args) {
    JFFinal llamada = new JFFinal();
    llamada.show();
    
    }
    
}
